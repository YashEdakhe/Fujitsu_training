package fujitsu.sampleweb;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		Hashtable<String,String> ht = new Hashtable<>();
		ht.put("Shembdya","Kutrya");
		ht.put("Simple","Complex");
		
		
		PrintWriter out = response.getWriter(); 
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		Iterator it = ht.keySet().iterator();
		while(it.hasNext()){
			String key = (String)it.next();
			if(key.equals(username)){
			String value = (String)ht.get(key);
			System.out.println(value);
			if(value.equals(password))
			{
				RequestDispatcher rd = request.getRequestDispatcher("HomeServlet");
				rd.forward(request,response);
			}
			else{
				out.println("<html><body><font color='red'>Enter Username and Password correctly"
						+ "</body></html>");
				RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
				rd.include(request,response);
				
			}
		}
	}
			
			
	}

}
