package sample;
public class Sample1
	{
	public	Sample1()
		{
		System.out.println("Costructor Called from Package");
		}
	}