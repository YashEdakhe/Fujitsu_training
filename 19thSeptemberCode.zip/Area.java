package sample;
public class Area
{
	public float area = 0.0f;
	public void areaOfCircle(float r)
		{
		area = 3.14f * (r*r);
		System.out.println("Area of Circle "+area);
		}
	public void areaOfRectangle(float l,float b)
		{
		area = l * b;
		System.out.println("Area of Rectangle "+area);
		}
	public void areaOfTriangle(float bre, float hei)
		{
		area = 0.5f*(bre*hei);
		System.out.println("Area of Triangle "+area);
		}	
	}
