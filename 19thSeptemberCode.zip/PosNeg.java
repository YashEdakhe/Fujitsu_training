class PosNeg
	{
		public static void main(String args[])
		{
		int pos = 0;
		int neg = 0;
		int count1 = 1;
		int count2 = 1;
		int a[] = {-2,-5,-8,-6,3,6,2,1,56,54};
		for(int i = 0; i < 10;i++)
			{
			if(a[i]<0)
			{
			neg = count1++;
			}
			else if(a[i]>0)
			{
			pos = count2++;
			}
			}
		System.out.println("Total Positive Integers are "+pos);
		System.out.println("Total negative Integers are "+neg);
		}	
	}