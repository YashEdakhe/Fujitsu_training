class AscDesc
{
	public static void main(String args[])
		{
		
		int a[] = {8,4,3,6,7,9};
		for(int i = 0;i<3;i++)
			{
			for(int j=i+1;j<3;j++)
			{
				if(a[i]>a[j])
				{
				int temp = a[i];
				a[i] = a[j];
				a[j] = temp;
				}
			}

                    
                  }
		for(int i = 3;i<6;i++)
			{
			for(int j=i+1;j<6;j++)
			{
				if(a[i]<a[j])
				{
				int temp = a[i];
				a[i] = a[j];
				a[j] = temp;
				}
			}
                    
                	}

for(int i=0;i<6;i++)
System.out.println(a[i]);
	}
		
}