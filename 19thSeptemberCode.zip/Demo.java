import sample.*;
class Demo
	{
	public static void main(String args[])
		{
		Sample1 s1 = new Sample1();
		}
	}