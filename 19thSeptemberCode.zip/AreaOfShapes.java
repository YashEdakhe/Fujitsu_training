import sample.*;
class AreaOfShapes
	{
	public static void main(String args[])
		{
		Area a = new Area();
		a.areaOfCircle(8);
		a.areaOfTriangle(5,6);
		a.areaOfRectangle(7,2);
		}
	}