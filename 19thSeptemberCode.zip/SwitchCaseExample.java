import java.util.Scanner;
class SwitchCaseExample
{
	public static void main(String args[])
	{
	int choice = 0; int num,temp;
        String s;
        int sum=0;
        int rem=0;
while(true){
	System.out.println("\nPress \n1.Armstrong Number \n2.Palindrome \n3.String Reverse\n");
	Scanner scan = new Scanner(System.in);
        choice=scan.nextInt();
	switch(choice)
		{
		case   1 :  System.out.println("Enter number to check if it's Armstrong");
                               num=scan.nextInt();
                             temp=num;
                             while(temp>0){
                             rem=temp%10;
                             sum=sum+(rem*rem*rem);
                             temp=temp/10;
                              }
                              if(sum==num){
                             System.out.println("Number is Armstrong "+sum);
			     
                              }  else{
                             System.out.println("Number is not a Armstrong"+sum);
                             }
			   break;
		case 2 :
                         System.out.println("Enter number to check if it's Palindrome");
                               num=scan.nextInt();
                       temp=num;
                        while(temp>0){
                        rem=temp%10;
                        sum=(sum*10)+rem;
                        temp=temp/10;
                        }
                      if(sum==num)
                               {
                                  System.out.println("Number is Palindrome"+sum);
                              }    
                      else      
                              {
                                  System.out.println("Number is not a Palindrome"+sum);
                             }

			break;
		case 3 :
                      System.out.println("Enter a string ");
                      s=scan.next();
                      String rev="";
                     int len=s.length();
                        for(int i=len-1;i>=0;i--)
                         {
//System.out.println(i);
                           rev=rev+s.charAt(i);                  
                         }

                          if(s.equals(rev))
                              {
                             System.out.println("Reverse of String"+ s);    
                              }
			break;
		}
	}	
}

}