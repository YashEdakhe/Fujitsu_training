package fujitsu.shape;

public interface CalArea{
	public static float rad=0.0f;
	public final static float pi = 3.14f;
	float calcArea(float rad);
}
