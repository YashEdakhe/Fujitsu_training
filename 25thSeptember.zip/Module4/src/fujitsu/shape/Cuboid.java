package fujitsu.shape;

public class Cuboid implements CalVolume {

	@Override
	public float calcVolume(float a) {
		float area = a * a * a;
		return area;
	}

}
