package fujitsu.animal;

public class Cat extends Animal{
	public void sound(){
		System.out.println("Meow-Meow");
	}
}
